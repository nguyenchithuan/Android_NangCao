# FPL_ASM_AndroidUI
FPL ASM AndroidUI
FPL Assignment Thiết kế giao diện trên Android - MOB202 

Documments: https://github.com/dinhtnguyenn/FPL_ASM_AndroidNC/tree/main/_readme

Videos: https://www.youtube.com/playlist?list=PLzNgKQA0vkdo-zrrcAql8FPk1svYXh2nx

Nếu gặp lỗi "Android Gradle plugin requires Java 11 to run. You are currently using Java 1.8" khi tải project về, thực hiện theo hướng dẫn sau:

Lỗi: 
[![IMAGE ALT TEXT HERE](https://raw.githubusercontent.com/dinhtnguyenn/FPL_ASM_AndroidUI/main/readme/error.png)](https://github.com/dinhtnguyenn/FPL_ASM_AndroidUI)

Fix lỗi:

Bước 1: Trong Android Studio --> chọn File --> Project Structure...

[![IMAGE ALT TEXT HERE](https://raw.githubusercontent.com/dinhtnguyenn/FPL_ASM_AndroidUI/main/readme/error-stp1.png)](https://github.com/dinhtnguyenn/FPL_ASM_AndroidUI)

Bước 2: Chọn SDK Location --> Gradle Settings

[![IMAGE ALT TEXT HERE](https://raw.githubusercontent.com/dinhtnguyenn/FPL_ASM_AndroidUI/main/readme/error-stp2.png)](https://github.com/dinhtnguyenn/FPL_ASM_AndroidUI)

Bước 3: Trong mục Gradle JDK, chọn Embedded JDK

[![IMAGE ALT TEXT HERE](https://raw.githubusercontent.com/dinhtnguyenn/FPL_ASM_AndroidUI/main/readme/error-stp3.png)](https://github.com/dinhtnguyenn/FPL_ASM_AndroidUI)


Một số hình ảnh:

[![IMAGE ALT TEXT HERE](https://raw.githubusercontent.com/dinhtnguyenn/FPL_ASM_AndroidNC/main/_readme/1.png)](https://github.com/dinhtnguyenn/FPL_ASM_AndroidNC)
[![IMAGE ALT TEXT HERE](https://raw.githubusercontent.com/dinhtnguyenn/FPL_ASM_AndroidNC/main/_readme/2.png)](https://github.com/dinhtnguyenn/FPL_ASM_AndroidNC)
[![IMAGE ALT TEXT HERE](https://raw.githubusercontent.com/dinhtnguyenn/FPL_ASM_AndroidNC/main/_readme/3.png)](https://github.com/dinhtnguyenn/FPL_ASM_AndroidNC)
[![IMAGE ALT TEXT HERE](https://raw.githubusercontent.com/dinhtnguyenn/FPL_ASM_AndroidNC/main/_readme/4.png)](https://github.com/dinhtnguyenn/FPL_ASM_AndroidNC)
[![IMAGE ALT TEXT HERE](https://raw.githubusercontent.com/dinhtnguyenn/FPL_ASM_AndroidNC/main/_readme/5.png)](https://github.com/dinhtnguyenn/FPL_ASM_AndroidNC)
[![IMAGE ALT TEXT HERE](https://raw.githubusercontent.com/dinhtnguyenn/FPL_ASM_AndroidNC/main/_readme/6.png)](https://github.com/dinhtnguyenn/FPL_ASM_AndroidNC)
[![IMAGE ALT TEXT HERE](https://raw.githubusercontent.com/dinhtnguyenn/FPL_ASM_AndroidNC/main/_readme/7.png)](https://github.com/dinhtnguyenn/FPL_ASM_AndroidNC)
